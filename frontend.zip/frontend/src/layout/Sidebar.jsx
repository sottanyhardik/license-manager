import {Link} from "react-router-dom";
import {useContext} from "react";
import {AuthContext} from "../context/AuthContext";
import {routes} from "../routes/config";

export default function Sidebar() {
    const {hasRole} = useContext(AuthContext);

    return (
        <div className="bg-dark text-white sidebar p-3" style={{width: "240px", minHeight: "100vh"}}>
            <h4 className="text-center mb-4">Admin Panel</h4>

            <ul className="nav nav-pills flex-column">
                {routes
                    .filter((r) => !r.protected || hasRole(r.roles))
                    .map((r) => (
                        <li key={r.path} className="nav-item mb-2">
                            <Link className="nav-link text-white" to={r.path}>
                                <i className={`bi bi-${r.icon} me-2`}/>
                                {r.label}
                            </Link>
                        </li>
                    ))}
            </ul>
        </div>
    );
}
