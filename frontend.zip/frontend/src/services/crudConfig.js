import { api } from './api';

// helper to fetch options
async function optionsEndpointFor(endpoint, valueKey = 'id', labelKey = 'name') {
  const data = await api.get(endpoint).catch(() => []);
  const arr = Array.isArray(data) ? data : (data.results || []);
  return arr.map(x => ({ value: x[valueKey], label: x[labelKey] ?? String(x) }));
}

export const licenseLocalSchema = {
  title: 'License',
  fields: [
    { name: 'license_number', label: 'License Number', type: 'text', default: '' },
    { name: 'license_date', label: 'License Date', type: 'date' },
    { name: 'license_expiry_date', label: 'Expiry Date', type: 'date' },
    { name: 'exporter', label: 'Exporter', type: 'select', optionsEndpoint: () => optionsEndpointFor('/companies/', 'id', 'name') },
    { name: 'file_number', label: 'File Number', type: 'text' },
    { name: 'scheme_code', label: 'Scheme Code', type: 'select', options: [{ value: '26', label: '26 - DFIA' }] },
  ],
  nested: [
    {
      name: 'import_items',
      label: 'Import Items',
      template: { serial_number: '', hs_code: '', description: '', quantity: 0, cif_fc: 0 },
      fields: [
        { name: 'serial_number', label: 'SR No' },
        { name: 'hs_code', label: 'HS Code', type: 'select', optionsEndpoint: () => optionsEndpointFor('/hscodes/', 'hs_code', 'hs_code') },
        { name: 'description', label: 'Description' },
        { name: 'quantity', label: 'Quantity', type: 'number' },
        { name: 'cif_fc', label: 'CIF (FC)', type: 'number' },
      ],
    },
    {
      name: 'export_items',
      label: 'Export Items',
      template: { item_id: null, description: '', cif_fc: 0, net_quantity: 0 },
      fields: [
        { name: 'item_id', label: 'Item', type: 'select', optionsEndpoint: () => optionsEndpointFor('/items/', 'id', 'name') },
        { name: 'description', label: 'Description' },
        { name: 'net_quantity', label: 'Net Qty', type: 'number' },
        { name: 'cif_fc', label: 'CIF (FC)', type: 'number' },
      ],
    },
  ],
  viewFields: ['license_number', 'license_date', 'license_expiry_date', 'scheme_code', 'file_number'],
  api: {
    list: (p) => api.listLicenses(p),
    get: (id) => api.getLicense(id),
    create: (payload) => api.createLicense(payload),
    update: (id, payload) => api.updateLicense(id, payload),
    remove: (id) => api.deleteLicense(id),
  },
  titleField: 'license_number',
  createUrl: '/licenses/new',
  editUrl: (id) => `/licenses/${id}/edit`,
  viewUrl: (id) => `/licenses/${id}`,
  listUrl: '/licenses',
};
