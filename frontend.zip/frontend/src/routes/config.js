export const routes = [
    {
        path: "/dashboard",
        label: "Dashboard",
        component: "Dashboard",
        protected: true,
        roles: ["admin", "manager", "viewer"],
        icon: "speedometer2",
    },
    {
        path: "/licenses",
        label: "Licenses",
        component: "LicensePage",
        protected: true,
        roles: ["admin", "manager"],
        icon: "file-earmark-text",
    },
    {
        path: "/settings",
        label: "Settings",
        component: "Settings",
        protected: true,
        roles: ["admin"],
        icon: "gear",
    },
];
