import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  return (
    <header className="header">
      <div className="app-container flex items-center justify-between py-4">
        <div className="flex items-center gap-4">
          <Link to="/" className="text-lg font-semibold" style={{ color: 'var(--brand)' }}>License Manager</Link>
        </div>

        <nav className="flex items-center gap-4">
          <Link to="/licenses" className="text-sm text-gray-700 hover:underline">Licenses</Link>
          {user ? (
            <>
              <span className="text-sm">Hi, {user.username}</span>
              <button onClick={() => { logout(); nav('/login'); }} className="px-3 py-1 border rounded">Logout</button>
            </>
          ) : (
            <Link to="/login" className="px-3 py-1 border rounded">Login</Link>
          )}
        </nav>
      </div>
    </header>
  );
}
