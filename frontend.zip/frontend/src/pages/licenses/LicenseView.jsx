import React from 'react';
import GenericView from '../../components/crud/GenericView';
import { licenseLocalSchema } from '../../services/crudConfig';
import { useParams } from 'react-router-dom';

export function LicenseViewPage() {
  const { id } = useParams();
  return <GenericView resource="licenses" config={licenseLocalSchema} id={id} />;
}
