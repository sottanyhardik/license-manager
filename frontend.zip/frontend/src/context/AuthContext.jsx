import {createContext, useEffect, useState} from "react";
import api from "../api/axios";

export const AuthContext = createContext();

export const AuthProvider = ({children}) => {
    const [user, setUser] = useState(
        localStorage.getItem("user")
            ? JSON.parse(localStorage.getItem("user"))
            : null
    );

    const [loading, setLoading] = useState(true);

    const login = (data) => {
        localStorage.setItem("access", data.access);
        localStorage.setItem("refresh", data.refresh);
        localStorage.setItem("user", JSON.stringify(data.user));

        setUser(data.user);
    };

    const logout = async () => {
        try {
            await api.post("/auth/logout/");
        } catch (e) {
            // backend might not enforce logout — ignore
        }

        localStorage.clear();
        setUser(null);
        window.location.href = "/login";
    };

    // Fetch current user on mount
    useEffect(() => {
        async function loadUser() {
            try {
                const {data} = await api.get("/auth/me/");
                setUser(data);
                localStorage.setItem("user", JSON.stringify(data));
            } catch {
                localStorage.clear();
            } finally {
                setLoading(false);
            }
        }

        loadUser();
    }, []);

    const hasRole = (roles) => {
        return user && roles.includes(user.role);
    };

    return (
        <AuthContext.Provider value={{user, login, logout, hasRole, loading}}>
            {children}
        </AuthContext.Provider>
    );
};
