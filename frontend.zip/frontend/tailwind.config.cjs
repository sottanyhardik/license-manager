module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#ff7a00' /* orange */,
          dark: '#ff6a00',
        },
        primary: '#333333',
      },
    },
  },
  plugins: [],
};
