// adapter so components can call useAuth() to get provider
import useAuthProvider from './useAuthProvider';
let instance = null;
export default function useAuth() {
  if (!instance) instance = useAuthProvider();
  return instance;
}
