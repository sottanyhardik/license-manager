// src/api/apiClient.js
import axios from "axios";
import { toast } from "react-toastify";

const apiClient = axios.create({
  baseURL: "/api", // use Vite proxy or CORS-enabled backend
  timeout: 15000,
  withCredentials: false, // set true if using cookie/session auth
});

// attach tokens from localStorage
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("access");
  if (token) {
    config.headers = config.headers || {};
    config.headers["Authorization"] = `Bearer ${token}`;
  }
  return config;
});

// global response error handler
apiClient.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response) {
      const message = err.response.data?.detail || err.response.data?.message || err.message;
      toast.error(message);
    } else {
      toast.error("Network error or server unreachable");
    }
    return Promise.reject(err);
  }
);

export default apiClient;
