import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import { LicenseListPage } from './pages/licenses/LicenseList';
import { LicenseFormPage } from './pages/licenses/LicenseForm';
import { LicenseViewPage } from './pages/licenses/LicenseView';

export default function App() {
  return (
    <div>
      <Navbar />
      <main className="app-container mt-6">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Dashboard />} />
          <Route path="/licenses" element={<LicenseListPage />} />
          <Route path="/licenses/new" element={<LicenseFormPage />} />
          <Route path="/licenses/:id" element={<LicenseViewPage />} />
          <Route path="/licenses/:id/edit" element={<LicenseFormPage editMode />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
