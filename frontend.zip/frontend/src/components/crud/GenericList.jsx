import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import useCrud from '../../hooks/useCrud';

export default function GenericList({ resource, config }) {
  // config.api should have list/get/create/update/remove
  const api = config?.api;
  const crud = useCrud({ list: api.list, get: api.get, create: api.create, update: api.update, remove: api.remove });
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    crud.fetchList().then(data => { if (!mounted) return; setItems(Array.isArray(data) ? data : (data.results || [])); }).finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, []);

  async function handleDelete(id) {
    if (!confirm('Delete?')) return;
    await crud.deleteOne(id);
    // reload
    const data = await crud.fetchList();
    setItems(Array.isArray(data) ? data : (data.results || []));
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold">{config.title || resource}</h1>
        <Link to={config.createUrl || `/${resource}/new`} className="btn-brand">New</Link>
      </div>

      {loading ? <p>Loading...</p> : (
        <div className="bg-white rounded shadow overflow-x-auto">
          <table className="w-full text-left min-w-[700px]">
            <thead className="bg-gray-50">
              <tr>
                {(config.columns || [{ key: 'id', label: '#' }]).map(c => <th key={c.key} className="p-3">{c.label}</th>)}
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((r, i) => (
                <tr key={r.id ?? i} className="border-t">
                  {(config.columns || [{ key: 'id' }]).map(c => <td key={c.key} className="p-3">{c.render ? c.render(r) : (r[c.key] ?? '-')}</td>)}
                  <td className="p-3">
                    <Link to={`/${resource}/${r.id}`} className="text-blue-600 mr-3">View</Link>
                    <Link to={`/${resource}/${r.id}/edit`} className="text-gray-700 mr-3">Edit</Link>
                    <button onClick={() => handleDelete(r.id)} className="text-red-600">Delete</button>
                  </td>
                </tr>
              ))}
              {!items.length && <tr><td colSpan={(config.columns||[]).length+1} className="p-4 text-center text-gray-500">No items</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
