import React from 'react';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <Link to="/licenses/new" className="btn-brand">New License</Link>
      </div>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">
          <h3 className="text-sm text-gray-500">Total Licenses</h3>
          <p className="text-2xl font-semibold">—</p>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="text-sm text-gray-500">Scheme</h3>
          <p className="text-2xl font-semibold">26</p>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="text-sm text-gray-500">Theme</h3>
          <p className="text-2xl font-semibold">Orange</p>
        </div>
      </section>
    </div>
  );
}
