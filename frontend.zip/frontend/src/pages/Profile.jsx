export default function Profile() {
  return <h1>My Profile</h1>;
}
