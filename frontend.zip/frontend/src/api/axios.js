import axios from "axios";

const api = axios.create({
    baseURL: "http://127.0.0.1:8000/api/",
    headers: {"Content-Type": "application/json"},
});

// Attach access token
api.interceptors.request.use((config) => {
    const access = localStorage.getItem("access");
    if (access) config.headers.Authorization = `Bearer ${access}`;
    return config;
});

// Auto refresh & global 401/500 handling
api.interceptors.response.use(
    (res) => res,
    async (error) => {
        const original = error.config;

        // Refresh token
        if (error.response?.status === 401 && !original._retry) {
            const refresh = localStorage.getItem("refresh");
            if (!refresh) {
                localStorage.clear();
                window.location.href = "/login";
                return Promise.reject(error);
            }

            original._retry = true;

            try {
                const {data} = await axios.post(
                    "http://127.0.0.1:8000/api/auth/refresh/",
                    {refresh}
                );

                localStorage.setItem("access", data.access);

                api.defaults.headers.Authorization = `Bearer ${data.access}`;
                return api(original);

            } catch {
                localStorage.clear();
                window.location.href = "/login";
            }
        }

        if (error.response?.status === 500) {
            window.location.href = "/500";
        }

        return Promise.reject(error);
    }
);

export default api;
