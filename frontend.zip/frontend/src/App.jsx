import {BrowserRouter, Route, Routes} from "react-router-dom";
import {lazy, Suspense} from "react";

import GlobalErrorBoundary from "./components/GlobalErrorBoundary";
import {AuthProvider} from "./context/AuthContext";
import {ToastProvider} from "./components/ToastContext";

import ProtectedRoute from "./routes/ProtectedRoute";
import RoleRoute from "./routes/RoleRoute";
import AdminLayout from "./layout/AdminLayout";

import {routes} from "./routes/config";

// Static pages
import Login from "./pages/Login";
import Unauthorized from "./pages/errors/Unauthorized";
import NotFound from "./pages/errors/NotFound";
import ServerError from "./pages/errors/ServerError";

export default function App() {
    return (
        <GlobalErrorBoundary>
            <AuthProvider>
                <ToastProvider>
                    <BrowserRouter>
                        <Suspense fallback={<div className="p-4">Loading...</div>}>

                            <Routes>
                                {/* Public routes */}
                                <Route path="/login" element={<Login/>}/>
                                <Route path="/401" element={<Unauthorized/>}/>
                                <Route path="/500" element={<ServerError/>}/>

                                {/* Protected dynamic routes */}
                                {routes.map((r) => {
                                    const Page = lazy(() => import(`./pages/${r.component}.jsx`));

                                    return (
                                        <Route
                                            key={r.path}
                                            path={r.path}
                                            element={
                                                <ProtectedRoute>
                                                    <RoleRoute roles={r.roles}>
                                                        <AdminLayout>
                                                            <Page/>
                                                        </AdminLayout>
                                                    </RoleRoute>
                                                </ProtectedRoute>
                                            }
                                        />
                                    );
                                })}

                                {/* 404 */}
                                <Route path="*" element={<NotFound/>}/>
                            </Routes>

                        </Suspense>
                    </BrowserRouter>
                </ToastProvider>
            </AuthProvider>
        </GlobalErrorBoundary>
    );
}
