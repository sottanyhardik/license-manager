import { useState, useEffect } from 'react';
import { api } from '../services/api';
import parseJwt from '../utils/parseJwt';
import toast from 'react-hot-toast';

function getToken() { try { return localStorage.getItem('authToken'); } catch { return null; } }
function setToken(t) { try { localStorage.setItem('authToken', t); } catch {} }
function removeToken() { try { localStorage.removeItem('authToken'); } catch {} }

export default function useAuthProvider() {
  const [user, setUser] = useState(() => {
    const t = getToken();
    if (!t) return null;
    try { return parseJwt(t); } catch { return null; }
  });

  useEffect(() => {
    let mounted = true;
    const t = getToken();
    if (t && mounted) {
      api.me().then(me => { if (mounted) setUser(me || parseJwt(t)); }).catch(() => { if (mounted) setUser(parseJwt(t)); });
    }
    return () => { mounted = false; };
  }, []);

  async function login(credentials) {
    const data = await api.login(credentials);
    if (!data || !data.token) throw new Error('Invalid login response');
    setToken(data.token);
    try { setUser(parseJwt(data.token)); } catch { setUser(data.user || null); }
    toast.success('Logged in');
    return data;
  }

  function logout() {
    removeToken();
    setUser(null);
    toast.success('Logged out');
  }

  return { user, login, logout, setToken };
}
