import React, { useEffect, useState } from 'react';
import useCrud from '../../hooks/useCrud';
import { Link } from 'react-router-dom';

export default function GenericView({ resource, config, id }) {
  const crud = useCrud({ list: config.api.list, get: config.api.get, create: config.api.create, update: config.api.update, remove: config.api.remove });
  const [obj, setObj] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    crud.fetchOne(id).then(d => { setObj(d); }).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <p>Loading...</p>;
  if (!obj) return <p>Not found</p>;

  return (
    <div className="bg-white p-6 rounded shadow">
      <h1 className="text-xl font-bold mb-2">{obj[config.titleField || 'license_number'] || 'Item'}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(config.viewFields || Object.keys(obj)).map(k => (
          <div key={k}><strong>{(config.fieldLabels && config.fieldLabels[k]) || k}</strong><p>{String(obj[k] ?? '-')}</p></div>
        ))}
      </div>

      {(config.nested || []).map(n => (
        <div key={n.name} className="mt-4">
          <h3 className="font-medium">{n.label}</h3>
          <div className="mt-2 space-y-2">
            {(obj[n.name] || []).map((r, i) => (
              <div key={i} className="p-2 border rounded bg-gray-50">
                {(n.fields || Object.keys(r)).map(f => <div key={f}><strong>{(n.fieldLabels && n.fieldLabels[f]) || f}:</strong> {String(r[f] ?? '-')}</div>)}
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="mt-6">
        <Link to={config.editUrl ? config.editUrl(obj.id) : `/${resource}/${obj.id}/edit`} className="text-blue-600 mr-3">Edit</Link>
        <Link to={config.listUrl || `/${resource}`} className="text-gray-700">Back</Link>
      </div>
    </div>
  );
}
