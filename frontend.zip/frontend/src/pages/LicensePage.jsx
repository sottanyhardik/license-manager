export default function LicensePage() {
  return <h1>License Management</h1>;
}
