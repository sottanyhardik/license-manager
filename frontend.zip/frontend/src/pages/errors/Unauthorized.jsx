export default function Unauthorized() {
    return (
        <div className="container mt-5 text-center">
            <h1 className="text-danger">401</h1>
            <p>You are not allowed to view this page.</p>
        </div>
    );
}
