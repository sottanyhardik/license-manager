import React, { useEffect, useState } from 'react';
import useCrud from '../../hooks/useCrud';
import { Link } from 'react-router-dom';
import { api } from '../../services/api';

// Simple input renderer
function Field({ field, value, onChange, options = [] }) {
  const { name, label, type = 'text' } = field;
  if (type === 'select') {
    return (
      <div>
        <label className="block text-sm text-gray-600">{label}</label>
        <select name={name} value={value ?? ''} onChange={(e) => onChange(name, e.target.value)} className="w-full border rounded px-3 py-2">
          <option value="">— select —</option>
          {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>
    );
  }
  if (type === 'textarea') {
    return (
      <div>
        <label className="block text-sm text-gray-600">{label}</label>
        <textarea name={name} value={value ?? ''} onChange={(e) => onChange(name, e.target.value)} className="w-full border rounded px-3 py-2" />
      </div>
    );
  }
  return (
    <div>
      <label className="block text-sm text-gray-600">{label}</label>
      <input name={name} type={type} value={value ?? ''} onChange={(e) => onChange(name, e.target.value)} className="w-full border rounded px-3 py-2" />
    </div>
  );
}

export default function GenericForm({ resource, config, editMode = false, id = null }) {
  // config.api must supply list/get/create/update/remove
  const apiCfg = config.api;
  const crud = useCrud({ list: apiCfg.list, get: apiCfg.get, create: apiCfg.create, update: apiCfg.update, remove: apiCfg.remove });

  const [schema, setSchema] = useState(config.schema || null);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(editMode);

  // if no schema provided, attempt to fetch from /schema/:resource
  useEffect(() => {
    let mounted = true;
    async function loadSchema() {
      if (schema) return;
      const fromApi = await api.fetchSchema(resource).catch(() => null);
      if (mounted) setSchema(fromApi || config.schema || null);
    }
    loadSchema();
    return () => { mounted = false; };
  }, []);

  // initialize blank form from schema
  useEffect(() => {
    if (!schema) return;
    const init = {};
    (schema.fields || []).forEach(f => init[f.name] = f.default ?? '');
    (schema.nested || []).forEach(n => init[n.name] = n.default ?? []);
    setForm(init);
  }, [schema]);

  // load existing object for edit
  useEffect(() => {
    if (!editMode || !id) return;
    setLoading(true);
    crud.fetchOne(id).then(data => {
      // merge with schema defaults
      const next = { ...form, ...(data || {}) };
      setForm(next);
    }).finally(() => setLoading(false));
  }, [editMode, id, schema]);

  // load select options if field.optionsEndpoint present (callable)
  const [opts, setOpts] = useState({});
  useEffect(() => {
    let mounted = true;
    async function loadOptions() {
      if (!schema) return;
      for (const f of (schema.fields || [])) {
        if (f.type === 'select' && typeof f.optionsEndpoint === 'function') {
          try {
            const o = await f.optionsEndpoint();
            if (mounted) setOpts(prev => ({ ...prev, [f.name]: o }));
          } catch {}
        }
      }
      for (const n of (schema.nested || [])) {
        for (const f of (n.fields || [])) {
          if (f.type === 'select' && typeof f.optionsEndpoint === 'function') {
            try {
              const o = await f.optionsEndpoint();
              if (mounted) setOpts(prev => ({ ...prev, [f.name]: o }));
            } catch {}
          }
        }
      }
    }
    loadOptions();
    return () => { mounted = false; };
  }, [schema]);

  function changeField(name, value) { setForm(prev => ({ ...prev, [name]: value })); }
  function addNested(name, template = {}) { setForm(prev => ({ ...prev, [name]: [...(prev[name] || []), template] })); }
  function updateNested(name, idx, fieldName, val) {
    setForm(prev => { const arr = [...(prev[name] || [])]; arr[idx] = { ...arr[idx], [fieldName]: val }; return { ...prev, [name]: arr }; });
  }
  function removeNested(name, idx) { setForm(prev => { const arr = [...(prev[name] || [])]; arr.splice(idx, 1); return { ...prev, [name]: arr }; }); }

  async function submit(e) {
    e.preventDefault();
    try {
      if (editMode && id) await crud.updateOne(id, form);
      else await crud.createOne(form);
      if (config.onSuccess) config.onSuccess();
    } catch (err) { /* interceptor shows error */ }
  }

  if (!schema) return <p>Loading schema...</p>;
  if (loading) return <p>Loading object...</p>;

  return (
    <div className="bg-white p-6 rounded shadow max-w-4xl">
      <h1 className="text-xl font-semibold mb-4">{schema.title || resource}</h1>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(schema.fields || []).map(f => (
            <Field key={f.name} field={f} value={form[f.name]} onChange={changeField} options={opts[f.name] || f.options || []} />
          ))}
        </div>

        {(schema.nested || []).map(n => (
          <div key={n.name} className="mt-4 border-t pt-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium">{n.label}</h3>
              <button type="button" onClick={() => addNested(n.name, n.template || {})} className="btn-brand">Add</button>
            </div>

            {(form[n.name] || []).map((row, idx) => (
              <div key={idx} className="mb-3 p-3 border rounded">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {(n.fields || []).map(f => (
                    <Field key={f.name} field={f} value={row[f.name]} onChange={(nm, v) => updateNested(n.name, idx, nm, v)} options={opts[f.name] || f.options || []} />
                  ))}
                </div>
                <div className="mt-2">
                  <button type="button" onClick={() => removeNested(n.name, idx)} className="text-red-600">Remove</button>
                </div>
              </div>
            ))}
          </div>
        ))}

        <div className="flex items-center gap-2 mt-4">
          <button type="submit" className="btn-brand">{editMode ? 'Update' : 'Save'}</button>
          {config.cancelUrl && <Link to={config.cancelUrl} className="px-4 py-2 border rounded">Cancel</Link>}
        </div>
      </form>
    </div>
  );
}
