import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import toast from 'react-hot-toast';

export default function Login() {
  const [form, setForm] = useState({ username: '', password: '' });
  const nav = useNavigate();

  async function submit(e) {
    e.preventDefault();
    try {
      const data = await api.login(form);
      if (!data || !data.token) throw new Error('Invalid login response');
      localStorage.setItem('authToken', data.token);
      toast.success('Logged in');
      nav('/');
    } catch (err) {
      // apiClient interceptor already toasts errors
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h1 className="text-xl font-semibold mb-4" style={{ color: 'var(--brand)' }}>Login</h1>
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="block text-sm text-gray-600">Username</label>
          <input name="username" value={form.username} onChange={e => setForm({...form, username: e.target.value})} className="w-full border rounded px-3 py-2" required />
        </div>
        <div>
          <label className="block text-sm text-gray-600">Password</label>
          <input name="password" type="password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} className="w-full border rounded px-3 py-2" required />
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-brand" type="submit">Login</button>
        </div>
      </form>
    </div>
  );
}
