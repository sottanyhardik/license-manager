import {useContext, useState} from "react";
import api from "../api/axios";
import {AuthContext} from "../context/AuthContext";
import {ToastContext} from "../components/ToastContext";

export default function Login() {
    const {login} = useContext(AuthContext);
    const {showToast} = useContext(ToastContext);

    const [form, setForm] = useState({
        username: "",
        password: "",
    });

    const submit = async (e) => {
        e.preventDefault();
        try {
            const {data} = await api.post("/auth/login/", form);
            login(data);
            showToast("Login successful");
            window.location.href = "/dashboard";
        } catch {
            showToast("Invalid username or password", "danger");
        }
    };

    return (
        <div className="container mt-5" style={{maxWidth: "400px"}}>
            <div className="card p-4 shadow">
                <h3 className="mb-3 text-center">Login</h3>

                <form onSubmit={submit}>
                    <div className="mb-3">
                        <label className="form-label">Username</label>
                        <input
                            className="form-control"
                            onChange={(e) =>
                                setForm({...form, username: e.target.value})
                            }
                            required
                        />
                    </div>

                    <div className="mb-3">
                        <label className="form-label">Password</label>
                        <input
                            type="password"
                            className="form-control"
                            onChange={(e) =>
                                setForm({...form, password: e.target.value})
                            }
                            required
                        />
                    </div>

                    <button className="btn btn-primary w-100">Login</button>
                </form>

                <div className="mt-3 text-center">
                    <a href="/password-reset">Forgot Password?</a>
                </div>
            </div>
        </div>
    );
}
