--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Ubuntu 11.5-0ubuntu0.19.04.1)
-- Dumped by pg_dump version 11.5 (Ubuntu 11.5-0ubuntu0.19.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE lmanagement;
--
-- Name: lmanagement; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE lmanagement WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C.UTF-8' LC_CTYPE = 'C.UTF-8';


ALTER DATABASE lmanagement OWNER TO postgres;

\connect lmanagement

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: allotment_allotmentitems; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.allotment_allotmentitems (
    id integer NOT NULL,
    cif_inr double precision NOT NULL,
    cif_fc double precision NOT NULL,
    qty double precision NOT NULL,
    allotment_id integer NOT NULL,
    item_id integer NOT NULL,
    is_boe boolean NOT NULL
);


ALTER TABLE public.allotment_allotmentitems OWNER TO lmanagement;

--
-- Name: allotment_allotmentitems_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.allotment_allotmentitems_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.allotment_allotmentitems_id_seq OWNER TO lmanagement;

--
-- Name: allotment_allotmentitems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.allotment_allotmentitems_id_seq OWNED BY public.allotment_allotmentitems.id;


--
-- Name: allotment_allotmentmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.allotment_allotmentmodel (
    created_on date,
    id integer NOT NULL,
    type character varying(2) NOT NULL,
    required_quantity double precision NOT NULL,
    unit_value_per_unit double precision NOT NULL,
    item_name character varying(255) NOT NULL,
    contact_person character varying(255),
    contact_number character varying(255),
    modified_on date NOT NULL,
    company_id integer NOT NULL,
    created_by_id integer,
    modified_by_id integer,
    port_id integer,
    related_company_id integer
);


ALTER TABLE public.allotment_allotmentmodel OWNER TO lmanagement;

--
-- Name: allotment_allotmentmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.allotment_allotmentmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.allotment_allotmentmodel_id_seq OWNER TO lmanagement;

--
-- Name: allotment_allotmentmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.allotment_allotmentmodel_id_seq OWNED BY public.allotment_allotmentmodel.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO lmanagement;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO lmanagement;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO lmanagement;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO lmanagement;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO lmanagement;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO lmanagement;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO lmanagement;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO lmanagement;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO lmanagement;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO lmanagement;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO lmanagement;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO lmanagement;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: bill_of_entry_billofentrymodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.bill_of_entry_billofentrymodel (
    id integer NOT NULL,
    bill_of_entry_number character varying(25) NOT NULL,
    bill_of_entry_date date,
    exchange_rate double precision NOT NULL,
    invoice_no character varying(255),
    allotment_id integer,
    company_id integer,
    port_id integer,
    product_name character varying(255) NOT NULL,
    invoice_date date,
    is_fetch boolean NOT NULL,
    cha character varying(255),
    failed integer NOT NULL
);


ALTER TABLE public.bill_of_entry_billofentrymodel OWNER TO lmanagement;

--
-- Name: bill_of_entry_billofentrymodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.bill_of_entry_billofentrymodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bill_of_entry_billofentrymodel_id_seq OWNER TO lmanagement;

--
-- Name: bill_of_entry_billofentrymodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.bill_of_entry_billofentrymodel_id_seq OWNED BY public.bill_of_entry_billofentrymodel.id;


--
-- Name: bill_of_entry_rowdetails; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.bill_of_entry_rowdetails (
    id integer NOT NULL,
    row_type character varying(2) NOT NULL,
    transaction_type character varying(2) NOT NULL,
    cif_inr double precision NOT NULL,
    cif_fc double precision NOT NULL,
    qty double precision NOT NULL,
    bill_of_entry_id integer,
    sr_number_id integer NOT NULL
);


ALTER TABLE public.bill_of_entry_rowdetails OWNER TO lmanagement;

--
-- Name: bill_of_entry_rowdetails_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.bill_of_entry_rowdetails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bill_of_entry_rowdetails_id_seq OWNER TO lmanagement;

--
-- Name: bill_of_entry_rowdetails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.bill_of_entry_rowdetails_id_seq OWNED BY public.bill_of_entry_rowdetails.id;


--
-- Name: core_companymodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_companymodel (
    id integer NOT NULL,
    iec character varying(10) NOT NULL,
    name character varying(255),
    contact_person character varying(255),
    phone_number character varying(255),
    email character varying(254),
    pan character varying(20),
    is_fetch boolean NOT NULL,
    address text,
    failed integer NOT NULL,
    is_self boolean NOT NULL
);


ALTER TABLE public.core_companymodel OWNER TO lmanagement;

--
-- Name: core_companymodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_companymodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_companymodel_id_seq OWNER TO lmanagement;

--
-- Name: core_companymodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_companymodel_id_seq OWNED BY public.core_companymodel.id;


--
-- Name: core_headsionnormsmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_headsionnormsmodel (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(200),
    is_fetch boolean NOT NULL,
    tpages integer NOT NULL,
    tcurrent integer NOT NULL
);


ALTER TABLE public.core_headsionnormsmodel OWNER TO lmanagement;

--
-- Name: core_headsionnormsmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_headsionnormsmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_headsionnormsmodel_id_seq OWNER TO lmanagement;

--
-- Name: core_headsionnormsmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_headsionnormsmodel_id_seq OWNED BY public.core_headsionnormsmodel.id;


--
-- Name: core_hscodemodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_hscodemodel (
    id integer NOT NULL,
    hs_code character varying(8) NOT NULL,
    product_description text,
    basic_duty character varying(225),
    unit character varying(255),
    policy character varying(255),
    note text
);


ALTER TABLE public.core_hscodemodel OWNER TO lmanagement;

--
-- Name: core_hscodemodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_hscodemodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_hscodemodel_id_seq OWNER TO lmanagement;

--
-- Name: core_hscodemodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_hscodemodel_id_seq OWNED BY public.core_hscodemodel.id;


--
-- Name: core_itemheadmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_itemheadmodel (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    hs_code character varying(255) NOT NULL,
    is_amend boolean NOT NULL
);


ALTER TABLE public.core_itemheadmodel OWNER TO lmanagement;

--
-- Name: core_itemheadmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_itemheadmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_itemheadmodel_id_seq OWNER TO lmanagement;

--
-- Name: core_itemheadmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_itemheadmodel_id_seq OWNED BY public.core_itemheadmodel.id;


--
-- Name: core_itemnamemodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_itemnamemodel (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    head_id integer
);


ALTER TABLE public.core_itemnamemodel OWNER TO lmanagement;

--
-- Name: core_itemnamemodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_itemnamemodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_itemnamemodel_id_seq OWNER TO lmanagement;

--
-- Name: core_itemnamemodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_itemnamemodel_id_seq OWNED BY public.core_itemnamemodel.id;


--
-- Name: core_portmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_portmodel (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(255)
);


ALTER TABLE public.core_portmodel OWNER TO lmanagement;

--
-- Name: core_portmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_portmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_portmodel_id_seq OWNER TO lmanagement;

--
-- Name: core_portmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_portmodel_id_seq OWNED BY public.core_portmodel.id;


--
-- Name: core_sionexportmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_sionexportmodel (
    id integer NOT NULL,
    quantity double precision NOT NULL,
    unit character varying(255),
    item_id integer,
    norm_class_id integer NOT NULL
);


ALTER TABLE public.core_sionexportmodel OWNER TO lmanagement;

--
-- Name: core_sionexportmodel_hs_code; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_sionexportmodel_hs_code (
    id integer NOT NULL,
    sionexportmodel_id integer NOT NULL,
    hscodemodel_id integer NOT NULL
);


ALTER TABLE public.core_sionexportmodel_hs_code OWNER TO lmanagement;

--
-- Name: core_sionexportmodel_hs_code_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_sionexportmodel_hs_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_sionexportmodel_hs_code_id_seq OWNER TO lmanagement;

--
-- Name: core_sionexportmodel_hs_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_sionexportmodel_hs_code_id_seq OWNED BY public.core_sionexportmodel_hs_code.id;


--
-- Name: core_sionexportmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_sionexportmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_sionexportmodel_id_seq OWNER TO lmanagement;

--
-- Name: core_sionexportmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_sionexportmodel_id_seq OWNED BY public.core_sionexportmodel.id;


--
-- Name: core_sionimportmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_sionimportmodel (
    id integer NOT NULL,
    sr_no integer NOT NULL,
    quantity double precision NOT NULL,
    unit character varying(255),
    condition character varying(255),
    item_id integer,
    norm_class_id integer NOT NULL
);


ALTER TABLE public.core_sionimportmodel OWNER TO lmanagement;

--
-- Name: core_sionimportmodel_hs_code; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_sionimportmodel_hs_code (
    id integer NOT NULL,
    sionimportmodel_id integer NOT NULL,
    hscodemodel_id integer NOT NULL
);


ALTER TABLE public.core_sionimportmodel_hs_code OWNER TO lmanagement;

--
-- Name: core_sionimportmodel_hs_code_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_sionimportmodel_hs_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_sionimportmodel_hs_code_id_seq OWNER TO lmanagement;

--
-- Name: core_sionimportmodel_hs_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_sionimportmodel_hs_code_id_seq OWNED BY public.core_sionimportmodel_hs_code.id;


--
-- Name: core_sionimportmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_sionimportmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_sionimportmodel_id_seq OWNER TO lmanagement;

--
-- Name: core_sionimportmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_sionimportmodel_id_seq OWNED BY public.core_sionimportmodel.id;


--
-- Name: core_sionnormclassmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.core_sionnormclassmodel (
    created_on date NOT NULL,
    id integer NOT NULL,
    norm_class character varying(10) NOT NULL,
    url character varying(200),
    is_fetch boolean NOT NULL,
    modified_on date NOT NULL,
    created_by_id integer,
    head_norm_id integer NOT NULL,
    item_id integer,
    modified_by_id integer
);


ALTER TABLE public.core_sionnormclassmodel OWNER TO lmanagement;

--
-- Name: core_sionnormclassmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.core_sionnormclassmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_sionnormclassmodel_id_seq OWNER TO lmanagement;

--
-- Name: core_sionnormclassmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.core_sionnormclassmodel_id_seq OWNED BY public.core_sionnormclassmodel.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO lmanagement;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO lmanagement;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO lmanagement;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO lmanagement;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO lmanagement;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO lmanagement;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO lmanagement;

--
-- Name: license_licensedetailsmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.license_licensedetailsmodel (
    id integer NOT NULL,
    scheme_code character varying(10) NOT NULL,
    notification_number character varying(10) NOT NULL,
    license_number character varying(50) NOT NULL,
    license_date date,
    license_expiry_date date,
    file_number character varying(30),
    registration_number character varying(10),
    registration_date date,
    user_comment text,
    user_restrictions text,
    is_audit boolean NOT NULL,
    exporter_id integer,
    port_id integer,
    is_null boolean NOT NULL,
    ledger_date date,
    is_self boolean NOT NULL
);


ALTER TABLE public.license_licensedetailsmodel OWNER TO lmanagement;

--
-- Name: license_licensedetailsmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.license_licensedetailsmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.license_licensedetailsmodel_id_seq OWNER TO lmanagement;

--
-- Name: license_licensedetailsmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.license_licensedetailsmodel_id_seq OWNED BY public.license_licensedetailsmodel.id;


--
-- Name: license_licensedocumentmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.license_licensedocumentmodel (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    file character varying(100) NOT NULL,
    license_id integer NOT NULL
);


ALTER TABLE public.license_licensedocumentmodel OWNER TO lmanagement;

--
-- Name: license_licensedocumentmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.license_licensedocumentmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.license_licensedocumentmodel_id_seq OWNER TO lmanagement;

--
-- Name: license_licensedocumentmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.license_licensedocumentmodel_id_seq OWNED BY public.license_licensedocumentmodel.id;


--
-- Name: license_licenseexportitemmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.license_licenseexportitemmodel (
    id integer NOT NULL,
    duty_type character varying(255) NOT NULL,
    net_quantity double precision NOT NULL,
    unit character varying(10) NOT NULL,
    fob_fc double precision NOT NULL,
    fob_inr double precision NOT NULL,
    fob_exchange_rate double precision NOT NULL,
    currency character varying(5) NOT NULL,
    value_addition double precision NOT NULL,
    cif_fc double precision NOT NULL,
    cif_inr double precision NOT NULL,
    item_id integer,
    license_id integer NOT NULL,
    norm_class_id integer
);


ALTER TABLE public.license_licenseexportitemmodel OWNER TO lmanagement;

--
-- Name: license_licenseexportitemmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.license_licenseexportitemmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.license_licenseexportitemmodel_id_seq OWNER TO lmanagement;

--
-- Name: license_licenseexportitemmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.license_licenseexportitemmodel_id_seq OWNED BY public.license_licenseexportitemmodel.id;


--
-- Name: license_licenseimportitemsmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.license_licenseimportitemsmodel (
    id integer NOT NULL,
    serial_number integer NOT NULL,
    duty_type character varying(255) NOT NULL,
    quantity double precision NOT NULL,
    unit character varying(10) NOT NULL,
    cif_fc double precision,
    cif_inr double precision NOT NULL,
    restricted_value_in_percentage double precision NOT NULL,
    restricted_value_per_unit double precision NOT NULL,
    blocked_value double precision NOT NULL,
    blocked_quantity double precision NOT NULL,
    available_quantity double precision NOT NULL,
    available_value double precision NOT NULL,
    hs_code_id integer,
    item_id integer,
    license_id integer NOT NULL
);


ALTER TABLE public.license_licenseimportitemsmodel OWNER TO lmanagement;

--
-- Name: license_licenseimportitemsmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.license_licenseimportitemsmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.license_licenseimportitemsmodel_id_seq OWNER TO lmanagement;

--
-- Name: license_licenseimportitemsmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.license_licenseimportitemsmodel_id_seq OWNED BY public.license_licenseimportitemsmodel.id;


--
-- Name: license_movement_licensemovementmodel; Type: TABLE; Schema: public; Owner: lmanagement
--

CREATE TABLE public.license_movement_licensemovementmodel (
    id integer NOT NULL,
    license_number character varying(15) NOT NULL,
    type character varying(2) NOT NULL,
    license_from character varying(255) NOT NULL,
    license_to character varying(255) NOT NULL,
    purpose character varying(255) NOT NULL,
    medium character varying(2) NOT NULL,
    courier_or_person_name character varying(255) NOT NULL,
    courier_or_person_number character varying(255) NOT NULL
);


ALTER TABLE public.license_movement_licensemovementmodel OWNER TO lmanagement;

--
-- Name: license_movement_licensemovementmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: lmanagement
--

CREATE SEQUENCE public.license_movement_licensemovementmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.license_movement_licensemovementmodel_id_seq OWNER TO lmanagement;

--
-- Name: license_movement_licensemovementmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lmanagement
--

ALTER SEQUENCE public.license_movement_licensemovementmodel_id_seq OWNED BY public.license_movement_licensemovementmodel.id;


--
-- Name: allotment_allotmentitems id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentitems ALTER COLUMN id SET DEFAULT nextval('public.allotment_allotmentitems_id_seq'::regclass);


--
-- Name: allotment_allotmentmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentmodel ALTER COLUMN id SET DEFAULT nextval('public.allotment_allotmentmodel_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: bill_of_entry_billofentrymodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_billofentrymodel ALTER COLUMN id SET DEFAULT nextval('public.bill_of_entry_billofentrymodel_id_seq'::regclass);


--
-- Name: bill_of_entry_rowdetails id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_rowdetails ALTER COLUMN id SET DEFAULT nextval('public.bill_of_entry_rowdetails_id_seq'::regclass);


--
-- Name: core_companymodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_companymodel ALTER COLUMN id SET DEFAULT nextval('public.core_companymodel_id_seq'::regclass);


--
-- Name: core_headsionnormsmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_headsionnormsmodel ALTER COLUMN id SET DEFAULT nextval('public.core_headsionnormsmodel_id_seq'::regclass);


--
-- Name: core_hscodemodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_hscodemodel ALTER COLUMN id SET DEFAULT nextval('public.core_hscodemodel_id_seq'::regclass);


--
-- Name: core_itemheadmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_itemheadmodel ALTER COLUMN id SET DEFAULT nextval('public.core_itemheadmodel_id_seq'::regclass);


--
-- Name: core_itemnamemodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_itemnamemodel ALTER COLUMN id SET DEFAULT nextval('public.core_itemnamemodel_id_seq'::regclass);


--
-- Name: core_portmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_portmodel ALTER COLUMN id SET DEFAULT nextval('public.core_portmodel_id_seq'::regclass);


--
-- Name: core_sionexportmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel ALTER COLUMN id SET DEFAULT nextval('public.core_sionexportmodel_id_seq'::regclass);


--
-- Name: core_sionexportmodel_hs_code id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel_hs_code ALTER COLUMN id SET DEFAULT nextval('public.core_sionexportmodel_hs_code_id_seq'::regclass);


--
-- Name: core_sionimportmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel ALTER COLUMN id SET DEFAULT nextval('public.core_sionimportmodel_id_seq'::regclass);


--
-- Name: core_sionimportmodel_hs_code id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel_hs_code ALTER COLUMN id SET DEFAULT nextval('public.core_sionimportmodel_hs_code_id_seq'::regclass);


--
-- Name: core_sionnormclassmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionnormclassmodel ALTER COLUMN id SET DEFAULT nextval('public.core_sionnormclassmodel_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: license_licensedetailsmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedetailsmodel ALTER COLUMN id SET DEFAULT nextval('public.license_licensedetailsmodel_id_seq'::regclass);


--
-- Name: license_licensedocumentmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedocumentmodel ALTER COLUMN id SET DEFAULT nextval('public.license_licensedocumentmodel_id_seq'::regclass);


--
-- Name: license_licenseexportitemmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseexportitemmodel ALTER COLUMN id SET DEFAULT nextval('public.license_licenseexportitemmodel_id_seq'::regclass);


--
-- Name: license_licenseimportitemsmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseimportitemsmodel ALTER COLUMN id SET DEFAULT nextval('public.license_licenseimportitemsmodel_id_seq'::regclass);


--
-- Name: license_movement_licensemovementmodel id; Type: DEFAULT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_movement_licensemovementmodel ALTER COLUMN id SET DEFAULT nextval('public.license_movement_licensemovementmodel_id_seq'::regclass);


--
-- Data for Name: allotment_allotmentitems; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.allotment_allotmentitems (id, cif_inr, cif_fc, qty, allotment_id, item_id, is_boe) FROM stdin;
\.
COPY public.allotment_allotmentitems (id, cif_inr, cif_fc, qty, allotment_id, item_id, is_boe) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: allotment_allotmentmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.allotment_allotmentmodel (created_on, id, type, required_quantity, unit_value_per_unit, item_name, contact_person, contact_number, modified_on, company_id, created_by_id, modified_by_id, port_id, related_company_id) FROM stdin;
\.
COPY public.allotment_allotmentmodel (created_on, id, type, required_quantity, unit_value_per_unit, item_name, contact_person, contact_number, modified_on, company_id, created_by_id, modified_by_id, port_id, related_company_id) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3306.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3308.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3304.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3310.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3314.dat';

--
-- Data for Name: bill_of_entry_billofentrymodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.bill_of_entry_billofentrymodel (id, bill_of_entry_number, bill_of_entry_date, exchange_rate, invoice_no, allotment_id, company_id, port_id, product_name, invoice_date, is_fetch, cha, failed) FROM stdin;
\.
COPY public.bill_of_entry_billofentrymodel (id, bill_of_entry_number, bill_of_entry_date, exchange_rate, invoice_no, allotment_id, company_id, port_id, product_name, invoice_date, is_fetch, cha, failed) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: bill_of_entry_rowdetails; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.bill_of_entry_rowdetails (id, row_type, transaction_type, cif_inr, cif_fc, qty, bill_of_entry_id, sr_number_id) FROM stdin;
\.
COPY public.bill_of_entry_rowdetails (id, row_type, transaction_type, cif_inr, cif_fc, qty, bill_of_entry_id, sr_number_id) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: core_companymodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_companymodel (id, iec, name, contact_person, phone_number, email, pan, is_fetch, address, failed, is_self) FROM stdin;
\.
COPY public.core_companymodel (id, iec, name, contact_person, phone_number, email, pan, is_fetch, address, failed, is_self) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: core_headsionnormsmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_headsionnormsmodel (id, name, url, is_fetch, tpages, tcurrent) FROM stdin;
\.
COPY public.core_headsionnormsmodel (id, name, url, is_fetch, tpages, tcurrent) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: core_hscodemodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_hscodemodel (id, hs_code, product_description, basic_duty, unit, policy, note) FROM stdin;
\.
COPY public.core_hscodemodel (id, hs_code, product_description, basic_duty, unit, policy, note) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: core_itemheadmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_itemheadmodel (id, name, hs_code, is_amend) FROM stdin;
\.
COPY public.core_itemheadmodel (id, name, hs_code, is_amend) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: core_itemnamemodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_itemnamemodel (id, name, head_id) FROM stdin;
\.
COPY public.core_itemnamemodel (id, name, head_id) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: core_portmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_portmodel (id, code, name) FROM stdin;
\.
COPY public.core_portmodel (id, code, name) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: core_sionexportmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_sionexportmodel (id, quantity, unit, item_id, norm_class_id) FROM stdin;
\.
COPY public.core_sionexportmodel (id, quantity, unit, item_id, norm_class_id) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: core_sionexportmodel_hs_code; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_sionexportmodel_hs_code (id, sionexportmodel_id, hscodemodel_id) FROM stdin;
\.
COPY public.core_sionexportmodel_hs_code (id, sionexportmodel_id, hscodemodel_id) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: core_sionimportmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_sionimportmodel (id, sr_no, quantity, unit, condition, item_id, norm_class_id) FROM stdin;
\.
COPY public.core_sionimportmodel (id, sr_no, quantity, unit, condition, item_id, norm_class_id) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: core_sionimportmodel_hs_code; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_sionimportmodel_hs_code (id, sionimportmodel_id, hscodemodel_id) FROM stdin;
\.
COPY public.core_sionimportmodel_hs_code (id, sionimportmodel_id, hscodemodel_id) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: core_sionnormclassmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.core_sionnormclassmodel (created_on, id, norm_class, url, is_fetch, modified_on, created_by_id, head_norm_id, item_id, modified_by_id) FROM stdin;
\.
COPY public.core_sionnormclassmodel (created_on, id, norm_class, url, is_fetch, modified_on, created_by_id, head_norm_id, item_id, modified_by_id) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3316.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3302.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3300.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: license_licensedetailsmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.license_licensedetailsmodel (id, scheme_code, notification_number, license_number, license_date, license_expiry_date, file_number, registration_number, registration_date, user_comment, user_restrictions, is_audit, exporter_id, port_id, is_null, ledger_date, is_self) FROM stdin;
\.
COPY public.license_licensedetailsmodel (id, scheme_code, notification_number, license_number, license_date, license_expiry_date, file_number, registration_number, registration_date, user_comment, user_restrictions, is_audit, exporter_id, port_id, is_null, ledger_date, is_self) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: license_licensedocumentmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.license_licensedocumentmodel (id, type, file, license_id) FROM stdin;
\.
COPY public.license_licensedocumentmodel (id, type, file, license_id) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: license_licenseexportitemmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.license_licenseexportitemmodel (id, duty_type, net_quantity, unit, fob_fc, fob_inr, fob_exchange_rate, currency, value_addition, cif_fc, cif_inr, item_id, license_id, norm_class_id) FROM stdin;
\.
COPY public.license_licenseexportitemmodel (id, duty_type, net_quantity, unit, fob_fc, fob_inr, fob_exchange_rate, currency, value_addition, cif_fc, cif_inr, item_id, license_id, norm_class_id) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: license_licenseimportitemsmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.license_licenseimportitemsmodel (id, serial_number, duty_type, quantity, unit, cif_fc, cif_inr, restricted_value_in_percentage, restricted_value_per_unit, blocked_value, blocked_quantity, available_quantity, available_value, hs_code_id, item_id, license_id) FROM stdin;
\.
COPY public.license_licenseimportitemsmodel (id, serial_number, duty_type, quantity, unit, cif_fc, cif_inr, restricted_value_in_percentage, restricted_value_per_unit, blocked_value, blocked_quantity, available_quantity, available_value, hs_code_id, item_id, license_id) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: license_movement_licensemovementmodel; Type: TABLE DATA; Schema: public; Owner: lmanagement
--

COPY public.license_movement_licensemovementmodel (id, license_number, type, license_from, license_to, purpose, medium, courier_or_person_name, courier_or_person_number) FROM stdin;
\.
COPY public.license_movement_licensemovementmodel (id, license_number, type, license_from, license_to, purpose, medium, courier_or_person_name, courier_or_person_number) FROM '$$PATH$$/3356.dat';

--
-- Name: allotment_allotmentitems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.allotment_allotmentitems_id_seq', 600, true);


--
-- Name: allotment_allotmentmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.allotment_allotmentmodel_id_seq', 147, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 96, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: bill_of_entry_billofentrymodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.bill_of_entry_billofentrymodel_id_seq', 4080, true);


--
-- Name: bill_of_entry_rowdetails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.bill_of_entry_rowdetails_id_seq', 9073, true);


--
-- Name: core_companymodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_companymodel_id_seq', 229, true);


--
-- Name: core_headsionnormsmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_headsionnormsmodel_id_seq', 16, true);


--
-- Name: core_hscodemodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_hscodemodel_id_seq', 13576, true);


--
-- Name: core_itemheadmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_itemheadmodel_id_seq', 19, true);


--
-- Name: core_itemnamemodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_itemnamemodel_id_seq', 145, true);


--
-- Name: core_portmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_portmodel_id_seq', 834, true);


--
-- Name: core_sionexportmodel_hs_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_sionexportmodel_hs_code_id_seq', 2, true);


--
-- Name: core_sionexportmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_sionexportmodel_id_seq', 5, true);


--
-- Name: core_sionimportmodel_hs_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_sionimportmodel_hs_code_id_seq', 71, true);


--
-- Name: core_sionimportmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_sionimportmodel_id_seq', 132, true);


--
-- Name: core_sionnormclassmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.core_sionnormclassmodel_id_seq', 6, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 99, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 24, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 54, true);


--
-- Name: license_licensedetailsmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.license_licensedetailsmodel_id_seq', 319, true);


--
-- Name: license_licensedocumentmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.license_licensedocumentmodel_id_seq', 22, true);


--
-- Name: license_licenseexportitemmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.license_licenseexportitemmodel_id_seq', 294, true);


--
-- Name: license_licenseimportitemsmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.license_licenseimportitemsmodel_id_seq', 4292, true);


--
-- Name: license_movement_licensemovementmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lmanagement
--

SELECT pg_catalog.setval('public.license_movement_licensemovementmodel_id_seq', 1, false);


--
-- Name: allotment_allotmentitems allotment_allotmentitems_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentitems
    ADD CONSTRAINT allotment_allotmentitems_pkey PRIMARY KEY (id);


--
-- Name: allotment_allotmentmodel allotment_allotmentmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentmodel
    ADD CONSTRAINT allotment_allotmentmodel_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: bill_of_entry_billofentrymodel bill_of_entry_billofentrymodel_bill_of_entry_number_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_billofentrymodel
    ADD CONSTRAINT bill_of_entry_billofentrymodel_bill_of_entry_number_key UNIQUE (bill_of_entry_number);


--
-- Name: bill_of_entry_billofentrymodel bill_of_entry_billofentrymodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_billofentrymodel
    ADD CONSTRAINT bill_of_entry_billofentrymodel_pkey PRIMARY KEY (id);


--
-- Name: bill_of_entry_rowdetails bill_of_entry_rowdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_rowdetails
    ADD CONSTRAINT bill_of_entry_rowdetails_pkey PRIMARY KEY (id);


--
-- Name: core_companymodel core_companymodel_iec_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_companymodel
    ADD CONSTRAINT core_companymodel_iec_key UNIQUE (iec);


--
-- Name: core_companymodel core_companymodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_companymodel
    ADD CONSTRAINT core_companymodel_pkey PRIMARY KEY (id);


--
-- Name: core_headsionnormsmodel core_headsionnormsmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_headsionnormsmodel
    ADD CONSTRAINT core_headsionnormsmodel_pkey PRIMARY KEY (id);


--
-- Name: core_hscodemodel core_hscodemodel_hs_code_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_hscodemodel
    ADD CONSTRAINT core_hscodemodel_hs_code_key UNIQUE (hs_code);


--
-- Name: core_hscodemodel core_hscodemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_hscodemodel
    ADD CONSTRAINT core_hscodemodel_pkey PRIMARY KEY (id);


--
-- Name: core_itemheadmodel core_itemheadmodel_name_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_itemheadmodel
    ADD CONSTRAINT core_itemheadmodel_name_key UNIQUE (name);


--
-- Name: core_itemheadmodel core_itemheadmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_itemheadmodel
    ADD CONSTRAINT core_itemheadmodel_pkey PRIMARY KEY (id);


--
-- Name: core_itemnamemodel core_itemnamemodel_name_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_itemnamemodel
    ADD CONSTRAINT core_itemnamemodel_name_key UNIQUE (name);


--
-- Name: core_itemnamemodel core_itemnamemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_itemnamemodel
    ADD CONSTRAINT core_itemnamemodel_pkey PRIMARY KEY (id);


--
-- Name: core_portmodel core_portmodel_name_code_9318ef75_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_portmodel
    ADD CONSTRAINT core_portmodel_name_code_9318ef75_uniq UNIQUE (name, code);


--
-- Name: core_portmodel core_portmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_portmodel
    ADD CONSTRAINT core_portmodel_pkey PRIMARY KEY (id);


--
-- Name: core_sionexportmodel_hs_code core_sionexportmodel_hs__sionexportmodel_id_hscod_cc20cef6_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel_hs_code
    ADD CONSTRAINT core_sionexportmodel_hs__sionexportmodel_id_hscod_cc20cef6_uniq UNIQUE (sionexportmodel_id, hscodemodel_id);


--
-- Name: core_sionexportmodel_hs_code core_sionexportmodel_hs_code_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel_hs_code
    ADD CONSTRAINT core_sionexportmodel_hs_code_pkey PRIMARY KEY (id);


--
-- Name: core_sionexportmodel core_sionexportmodel_norm_class_id_30ff5f0d_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel
    ADD CONSTRAINT core_sionexportmodel_norm_class_id_30ff5f0d_uniq UNIQUE (norm_class_id);


--
-- Name: core_sionexportmodel core_sionexportmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel
    ADD CONSTRAINT core_sionexportmodel_pkey PRIMARY KEY (id);


--
-- Name: core_sionimportmodel_hs_code core_sionimportmodel_hs__sionimportmodel_id_hscod_f05f64f4_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel_hs_code
    ADD CONSTRAINT core_sionimportmodel_hs__sionimportmodel_id_hscod_f05f64f4_uniq UNIQUE (sionimportmodel_id, hscodemodel_id);


--
-- Name: core_sionimportmodel_hs_code core_sionimportmodel_hs_code_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel_hs_code
    ADD CONSTRAINT core_sionimportmodel_hs_code_pkey PRIMARY KEY (id);


--
-- Name: core_sionimportmodel core_sionimportmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel
    ADD CONSTRAINT core_sionimportmodel_pkey PRIMARY KEY (id);


--
-- Name: core_sionnormclassmodel core_sionnormclassmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionnormclassmodel
    ADD CONSTRAINT core_sionnormclassmodel_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: license_licensedetailsmodel license_licensedetailsmodel_license_number_key; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedetailsmodel
    ADD CONSTRAINT license_licensedetailsmodel_license_number_key UNIQUE (license_number);


--
-- Name: license_licensedetailsmodel license_licensedetailsmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedetailsmodel
    ADD CONSTRAINT license_licensedetailsmodel_pkey PRIMARY KEY (id);


--
-- Name: license_licensedocumentmodel license_licensedocumentmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedocumentmodel
    ADD CONSTRAINT license_licensedocumentmodel_pkey PRIMARY KEY (id);


--
-- Name: license_licenseexportitemmodel license_licenseexportitemmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseexportitemmodel
    ADD CONSTRAINT license_licenseexportitemmodel_pkey PRIMARY KEY (id);


--
-- Name: license_licenseimportitemsmodel license_licenseimportitemsmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseimportitemsmodel
    ADD CONSTRAINT license_licenseimportitemsmodel_pkey PRIMARY KEY (id);


--
-- Name: license_movement_licensemovementmodel license_movement_licensemovementmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_movement_licensemovementmodel
    ADD CONSTRAINT license_movement_licensemovementmodel_pkey PRIMARY KEY (id);


--
-- Name: allotment_allotmentitems_allotment_id_eb2d2353; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX allotment_allotmentitems_allotment_id_eb2d2353 ON public.allotment_allotmentitems USING btree (allotment_id);


--
-- Name: allotment_allotmentitems_item_id_84e965e3; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX allotment_allotmentitems_item_id_84e965e3 ON public.allotment_allotmentitems USING btree (item_id);


--
-- Name: allotment_allotmentmodel_company_id_216611e9; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX allotment_allotmentmodel_company_id_216611e9 ON public.allotment_allotmentmodel USING btree (company_id);


--
-- Name: allotment_allotmentmodel_created_by_id_3c27962a; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX allotment_allotmentmodel_created_by_id_3c27962a ON public.allotment_allotmentmodel USING btree (created_by_id);


--
-- Name: allotment_allotmentmodel_modified_by_id_28774f9a; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX allotment_allotmentmodel_modified_by_id_28774f9a ON public.allotment_allotmentmodel USING btree (modified_by_id);


--
-- Name: allotment_allotmentmodel_port_id_4b2cd7e3; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX allotment_allotmentmodel_port_id_4b2cd7e3 ON public.allotment_allotmentmodel USING btree (port_id);


--
-- Name: allotment_allotmentmodel_related_company_id_bbfd3169; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX allotment_allotmentmodel_related_company_id_bbfd3169 ON public.allotment_allotmentmodel USING btree (related_company_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: bill_of_entry_billofentr_bill_of_entry_number_404c9106_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX bill_of_entry_billofentr_bill_of_entry_number_404c9106_like ON public.bill_of_entry_billofentrymodel USING btree (bill_of_entry_number varchar_pattern_ops);


--
-- Name: bill_of_entry_billofentrymodel_allotment_id_bd0748e9; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX bill_of_entry_billofentrymodel_allotment_id_bd0748e9 ON public.bill_of_entry_billofentrymodel USING btree (allotment_id);


--
-- Name: bill_of_entry_billofentrymodel_company_id_f84eea08; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX bill_of_entry_billofentrymodel_company_id_f84eea08 ON public.bill_of_entry_billofentrymodel USING btree (company_id);


--
-- Name: bill_of_entry_billofentrymodel_port_id_00350650; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX bill_of_entry_billofentrymodel_port_id_00350650 ON public.bill_of_entry_billofentrymodel USING btree (port_id);


--
-- Name: bill_of_entry_rowdetails_bill_of_entry_id_b00cd11e; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX bill_of_entry_rowdetails_bill_of_entry_id_b00cd11e ON public.bill_of_entry_rowdetails USING btree (bill_of_entry_id);


--
-- Name: bill_of_entry_rowdetails_sr_number_id_e050edb1; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX bill_of_entry_rowdetails_sr_number_id_e050edb1 ON public.bill_of_entry_rowdetails USING btree (sr_number_id);


--
-- Name: core_companymodel_iec_8b8840c6_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_companymodel_iec_8b8840c6_like ON public.core_companymodel USING btree (iec varchar_pattern_ops);


--
-- Name: core_hscodemodel_hs_code_70a1fd65_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_hscodemodel_hs_code_70a1fd65_like ON public.core_hscodemodel USING btree (hs_code varchar_pattern_ops);


--
-- Name: core_itemheadmodel_name_64d5bc4e_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_itemheadmodel_name_64d5bc4e_like ON public.core_itemheadmodel USING btree (name varchar_pattern_ops);


--
-- Name: core_itemnamemodel_head_id_3fdea8c6; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_itemnamemodel_head_id_3fdea8c6 ON public.core_itemnamemodel USING btree (head_id);


--
-- Name: core_itemnamemodel_name_1676e385_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_itemnamemodel_name_1676e385_like ON public.core_itemnamemodel USING btree (name varchar_pattern_ops);


--
-- Name: core_sionexportmodel_hs_code_hscodemodel_id_18e34cb6; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionexportmodel_hs_code_hscodemodel_id_18e34cb6 ON public.core_sionexportmodel_hs_code USING btree (hscodemodel_id);


--
-- Name: core_sionexportmodel_hs_code_sionexportmodel_id_3794e8df; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionexportmodel_hs_code_sionexportmodel_id_3794e8df ON public.core_sionexportmodel_hs_code USING btree (sionexportmodel_id);


--
-- Name: core_sionexportmodel_item_id_10161406; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionexportmodel_item_id_10161406 ON public.core_sionexportmodel USING btree (item_id);


--
-- Name: core_sionimportmodel_hs_code_hscodemodel_id_fa26b8bd; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionimportmodel_hs_code_hscodemodel_id_fa26b8bd ON public.core_sionimportmodel_hs_code USING btree (hscodemodel_id);


--
-- Name: core_sionimportmodel_hs_code_sionimportmodel_id_78d7e63c; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionimportmodel_hs_code_sionimportmodel_id_78d7e63c ON public.core_sionimportmodel_hs_code USING btree (sionimportmodel_id);


--
-- Name: core_sionimportmodel_item_id_46a39ea2; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionimportmodel_item_id_46a39ea2 ON public.core_sionimportmodel USING btree (item_id);


--
-- Name: core_sionimportmodel_norm_class_id_a90f4121; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionimportmodel_norm_class_id_a90f4121 ON public.core_sionimportmodel USING btree (norm_class_id);


--
-- Name: core_sionnormclassmodel_created_by_id_bd48feeb; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionnormclassmodel_created_by_id_bd48feeb ON public.core_sionnormclassmodel USING btree (created_by_id);


--
-- Name: core_sionnormclassmodel_head_norm_id_19945b71; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionnormclassmodel_head_norm_id_19945b71 ON public.core_sionnormclassmodel USING btree (head_norm_id);


--
-- Name: core_sionnormclassmodel_item_id_1b65b71c; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionnormclassmodel_item_id_1b65b71c ON public.core_sionnormclassmodel USING btree (item_id);


--
-- Name: core_sionnormclassmodel_modified_by_id_ec33e9b3; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX core_sionnormclassmodel_modified_by_id_ec33e9b3 ON public.core_sionnormclassmodel USING btree (modified_by_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: license_licensedetailsmodel_exporter_id_9d460980; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licensedetailsmodel_exporter_id_9d460980 ON public.license_licensedetailsmodel USING btree (exporter_id);


--
-- Name: license_licensedetailsmodel_license_number_05794b38_like; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licensedetailsmodel_license_number_05794b38_like ON public.license_licensedetailsmodel USING btree (license_number varchar_pattern_ops);


--
-- Name: license_licensedetailsmodel_port_id_bf017001; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licensedetailsmodel_port_id_bf017001 ON public.license_licensedetailsmodel USING btree (port_id);


--
-- Name: license_licensedocumentmodel_license_id_e6102298; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licensedocumentmodel_license_id_e6102298 ON public.license_licensedocumentmodel USING btree (license_id);


--
-- Name: license_licenseexportitemmodel_item_id_5b26d3a8; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licenseexportitemmodel_item_id_5b26d3a8 ON public.license_licenseexportitemmodel USING btree (item_id);


--
-- Name: license_licenseexportitemmodel_license_id_22192896; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licenseexportitemmodel_license_id_22192896 ON public.license_licenseexportitemmodel USING btree (license_id);


--
-- Name: license_licenseexportitemmodel_norm_class_id_764682fe; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licenseexportitemmodel_norm_class_id_764682fe ON public.license_licenseexportitemmodel USING btree (norm_class_id);


--
-- Name: license_licenseimportitemsmodel_hs_code_id_25f4836b; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licenseimportitemsmodel_hs_code_id_25f4836b ON public.license_licenseimportitemsmodel USING btree (hs_code_id);


--
-- Name: license_licenseimportitemsmodel_item_id_87f31a46; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licenseimportitemsmodel_item_id_87f31a46 ON public.license_licenseimportitemsmodel USING btree (item_id);


--
-- Name: license_licenseimportitemsmodel_license_id_503c5ff6; Type: INDEX; Schema: public; Owner: lmanagement
--

CREATE INDEX license_licenseimportitemsmodel_license_id_503c5ff6 ON public.license_licenseimportitemsmodel USING btree (license_id);


--
-- Name: allotment_allotmentitems allotment_allotmenti_allotment_id_eb2d2353_fk_allotment; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentitems
    ADD CONSTRAINT allotment_allotmenti_allotment_id_eb2d2353_fk_allotment FOREIGN KEY (allotment_id) REFERENCES public.allotment_allotmentmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allotment_allotmentitems allotment_allotmenti_item_id_84e965e3_fk_license_l; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentitems
    ADD CONSTRAINT allotment_allotmenti_item_id_84e965e3_fk_license_l FOREIGN KEY (item_id) REFERENCES public.license_licenseimportitemsmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allotment_allotmentmodel allotment_allotmentm_company_id_216611e9_fk_core_comp; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentmodel
    ADD CONSTRAINT allotment_allotmentm_company_id_216611e9_fk_core_comp FOREIGN KEY (company_id) REFERENCES public.core_companymodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allotment_allotmentmodel allotment_allotmentm_modified_by_id_28774f9a_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentmodel
    ADD CONSTRAINT allotment_allotmentm_modified_by_id_28774f9a_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allotment_allotmentmodel allotment_allotmentm_related_company_id_bbfd3169_fk_core_comp; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentmodel
    ADD CONSTRAINT allotment_allotmentm_related_company_id_bbfd3169_fk_core_comp FOREIGN KEY (related_company_id) REFERENCES public.core_companymodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allotment_allotmentmodel allotment_allotmentmodel_created_by_id_3c27962a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentmodel
    ADD CONSTRAINT allotment_allotmentmodel_created_by_id_3c27962a_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allotment_allotmentmodel allotment_allotmentmodel_port_id_4b2cd7e3_fk_core_portmodel_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.allotment_allotmentmodel
    ADD CONSTRAINT allotment_allotmentmodel_port_id_4b2cd7e3_fk_core_portmodel_id FOREIGN KEY (port_id) REFERENCES public.core_portmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bill_of_entry_billofentrymodel bill_of_entry_billof_allotment_id_bd0748e9_fk_allotment; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_billofentrymodel
    ADD CONSTRAINT bill_of_entry_billof_allotment_id_bd0748e9_fk_allotment FOREIGN KEY (allotment_id) REFERENCES public.allotment_allotmentmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bill_of_entry_billofentrymodel bill_of_entry_billof_company_id_f84eea08_fk_core_comp; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_billofentrymodel
    ADD CONSTRAINT bill_of_entry_billof_company_id_f84eea08_fk_core_comp FOREIGN KEY (company_id) REFERENCES public.core_companymodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bill_of_entry_billofentrymodel bill_of_entry_billof_port_id_00350650_fk_core_port; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_billofentrymodel
    ADD CONSTRAINT bill_of_entry_billof_port_id_00350650_fk_core_port FOREIGN KEY (port_id) REFERENCES public.core_portmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bill_of_entry_rowdetails bill_of_entry_rowdet_bill_of_entry_id_b00cd11e_fk_bill_of_e; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_rowdetails
    ADD CONSTRAINT bill_of_entry_rowdet_bill_of_entry_id_b00cd11e_fk_bill_of_e FOREIGN KEY (bill_of_entry_id) REFERENCES public.bill_of_entry_billofentrymodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bill_of_entry_rowdetails bill_of_entry_rowdet_sr_number_id_e050edb1_fk_license_l; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.bill_of_entry_rowdetails
    ADD CONSTRAINT bill_of_entry_rowdet_sr_number_id_e050edb1_fk_license_l FOREIGN KEY (sr_number_id) REFERENCES public.license_licenseimportitemsmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_itemnamemodel core_itemnamemodel_head_id_3fdea8c6_fk_core_itemheadmodel_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_itemnamemodel
    ADD CONSTRAINT core_itemnamemodel_head_id_3fdea8c6_fk_core_itemheadmodel_id FOREIGN KEY (head_id) REFERENCES public.core_itemheadmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionexportmodel_hs_code core_sionexportmodel_hscodemodel_id_18e34cb6_fk_core_hsco; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel_hs_code
    ADD CONSTRAINT core_sionexportmodel_hscodemodel_id_18e34cb6_fk_core_hsco FOREIGN KEY (hscodemodel_id) REFERENCES public.core_hscodemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionexportmodel core_sionexportmodel_item_id_10161406_fk_core_itemnamemodel_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel
    ADD CONSTRAINT core_sionexportmodel_item_id_10161406_fk_core_itemnamemodel_id FOREIGN KEY (item_id) REFERENCES public.core_itemnamemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionexportmodel core_sionexportmodel_norm_class_id_30ff5f0d_fk_core_sion; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel
    ADD CONSTRAINT core_sionexportmodel_norm_class_id_30ff5f0d_fk_core_sion FOREIGN KEY (norm_class_id) REFERENCES public.core_sionnormclassmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionexportmodel_hs_code core_sionexportmodel_sionexportmodel_id_3794e8df_fk_core_sion; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionexportmodel_hs_code
    ADD CONSTRAINT core_sionexportmodel_sionexportmodel_id_3794e8df_fk_core_sion FOREIGN KEY (sionexportmodel_id) REFERENCES public.core_sionexportmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionimportmodel_hs_code core_sionimportmodel_hscodemodel_id_fa26b8bd_fk_core_hsco; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel_hs_code
    ADD CONSTRAINT core_sionimportmodel_hscodemodel_id_fa26b8bd_fk_core_hsco FOREIGN KEY (hscodemodel_id) REFERENCES public.core_hscodemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionimportmodel core_sionimportmodel_item_id_46a39ea2_fk_core_itemnamemodel_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel
    ADD CONSTRAINT core_sionimportmodel_item_id_46a39ea2_fk_core_itemnamemodel_id FOREIGN KEY (item_id) REFERENCES public.core_itemnamemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionimportmodel core_sionimportmodel_norm_class_id_a90f4121_fk_core_sion; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel
    ADD CONSTRAINT core_sionimportmodel_norm_class_id_a90f4121_fk_core_sion FOREIGN KEY (norm_class_id) REFERENCES public.core_sionnormclassmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionimportmodel_hs_code core_sionimportmodel_sionimportmodel_id_78d7e63c_fk_core_sion; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionimportmodel_hs_code
    ADD CONSTRAINT core_sionimportmodel_sionimportmodel_id_78d7e63c_fk_core_sion FOREIGN KEY (sionimportmodel_id) REFERENCES public.core_sionimportmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionnormclassmodel core_sionnormclassmo_head_norm_id_19945b71_fk_core_head; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionnormclassmodel
    ADD CONSTRAINT core_sionnormclassmo_head_norm_id_19945b71_fk_core_head FOREIGN KEY (head_norm_id) REFERENCES public.core_headsionnormsmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionnormclassmodel core_sionnormclassmo_item_id_1b65b71c_fk_core_item; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionnormclassmodel
    ADD CONSTRAINT core_sionnormclassmo_item_id_1b65b71c_fk_core_item FOREIGN KEY (item_id) REFERENCES public.core_itemnamemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionnormclassmodel core_sionnormclassmodel_created_by_id_bd48feeb_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionnormclassmodel
    ADD CONSTRAINT core_sionnormclassmodel_created_by_id_bd48feeb_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sionnormclassmodel core_sionnormclassmodel_modified_by_id_ec33e9b3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.core_sionnormclassmodel
    ADD CONSTRAINT core_sionnormclassmodel_modified_by_id_ec33e9b3_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licensedetailsmodel license_licensedetai_exporter_id_9d460980_fk_core_comp; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedetailsmodel
    ADD CONSTRAINT license_licensedetai_exporter_id_9d460980_fk_core_comp FOREIGN KEY (exporter_id) REFERENCES public.core_companymodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licensedetailsmodel license_licensedetai_port_id_bf017001_fk_core_port; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedetailsmodel
    ADD CONSTRAINT license_licensedetai_port_id_bf017001_fk_core_port FOREIGN KEY (port_id) REFERENCES public.core_portmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licensedocumentmodel license_licensedocum_license_id_e6102298_fk_license_l; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licensedocumentmodel
    ADD CONSTRAINT license_licensedocum_license_id_e6102298_fk_license_l FOREIGN KEY (license_id) REFERENCES public.license_licensedetailsmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licenseexportitemmodel license_licenseexpor_item_id_5b26d3a8_fk_core_item; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseexportitemmodel
    ADD CONSTRAINT license_licenseexpor_item_id_5b26d3a8_fk_core_item FOREIGN KEY (item_id) REFERENCES public.core_itemnamemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licenseexportitemmodel license_licenseexpor_license_id_22192896_fk_license_l; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseexportitemmodel
    ADD CONSTRAINT license_licenseexpor_license_id_22192896_fk_license_l FOREIGN KEY (license_id) REFERENCES public.license_licensedetailsmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licenseexportitemmodel license_licenseexpor_norm_class_id_764682fe_fk_core_sion; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseexportitemmodel
    ADD CONSTRAINT license_licenseexpor_norm_class_id_764682fe_fk_core_sion FOREIGN KEY (norm_class_id) REFERENCES public.core_sionnormclassmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licenseimportitemsmodel license_licenseimpor_hs_code_id_25f4836b_fk_core_hsco; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseimportitemsmodel
    ADD CONSTRAINT license_licenseimpor_hs_code_id_25f4836b_fk_core_hsco FOREIGN KEY (hs_code_id) REFERENCES public.core_hscodemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licenseimportitemsmodel license_licenseimpor_item_id_87f31a46_fk_core_item; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseimportitemsmodel
    ADD CONSTRAINT license_licenseimpor_item_id_87f31a46_fk_core_item FOREIGN KEY (item_id) REFERENCES public.core_itemnamemodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: license_licenseimportitemsmodel license_licenseimpor_license_id_503c5ff6_fk_license_l; Type: FK CONSTRAINT; Schema: public; Owner: lmanagement
--

ALTER TABLE ONLY public.license_licenseimportitemsmodel
    ADD CONSTRAINT license_licenseimpor_license_id_503c5ff6_fk_license_l FOREIGN KEY (license_id) REFERENCES public.license_licensedetailsmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: DATABASE lmanagement; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE lmanagement TO lmanagement;


--
-- PostgreSQL database dump complete
--

