import axios from 'axios';
import toast from 'react-hot-toast';

const BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api';

const client = axios.create({ baseURL: BASE, withCredentials: true, headers: { 'Content-Type': 'application/json' } });

function getToken() {
  try { return localStorage.getItem('authToken'); } catch (e) { return null; }
}

client.interceptors.request.use((cfg) => {
  const token = getToken();
  if (token && cfg.headers) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
}, (err) => Promise.reject(err));

client.interceptors.response.use(
  (res) => res,
  (err) => {
    const res = err.response;
    if (!res) {
      toast.error('Network error. Check backend / internet.');
      return Promise.reject(err);
    }
    // auto logout on 401
    if (res.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('authToken');
      toast.error('Unauthorized — please login again.');
      // optionally reload
    }
    // format message
    const data = res.data;
    let msg = res.statusText || 'Error';
    if (data) {
      if (data.detail) msg = data.detail;
      else if (data.message) msg = data.message;
      else if (typeof data === 'object') {
        msg = Object.entries(data).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(', ') : v}`).join(' • ');
      } else if (typeof data === 'string') msg = data;
    }
    if (res.status >= 500) toast.error(`Server error: ${msg}`);
    else toast.error(msg);
    return Promise.reject(err);
  }
);

export default client;
