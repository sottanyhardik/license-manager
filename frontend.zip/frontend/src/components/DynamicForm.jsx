// src/components/DynamicForm.jsx
import React, { useEffect, useState } from "react";
import { getLicenseSchema, fetchOptions, submitLicense } from "../api/licenseApi";
import { toast } from "react-toastify";

/**
 * Minimal form renderer.
 * - schema: returned from /schema/ (fields list)
 * - For select/multiselect fields, options_endpoint is used to fetch options.
 */

const Input = ({ field, value, onChange }) => {
  const common = {
    id: field.name,
    name: field.name,
    value: value ?? "",
    onChange: (e) => onChange(field.name, e.target.value),
    required: field.required,
    placeholder: field.help_text || field.label,
    style: { padding: "8px", width: "100%", borderRadius: 4, border: "1px solid #ddd" },
  };

  if (field.type === "textarea") {
    return <textarea {...common} rows={4} />;
  }
  if (field.type === "number") {
    return <input {...common} type="number" />;
  }
  if (field.type === "date") {
    return <input {...common} type="date" />;
  }
  // fallback text
  return <input {...common} type="text" />;
};

const SelectWithSearch = ({ field, value, onChange }) => {
  const endpoint = field.options_endpoint;
  const [search, setSearch] = useState("");
  const [opts, setOpts] = useState([]);
  const [page, setPage] = useState(1);
  const [hasNext, setHasNext] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    fetchOptions(endpoint, { search, page })
      .then((data) => {
        if (!mounted) return;
        setOpts(data.results || []);
        setHasNext(!!data.next);
      })
      .finally(() => setLoading(false));
    return () => (mounted = false);
  }, [endpoint, search, page]);

  return (
    <div>
      <div style={{ marginBottom: 6 }}>
        <input
          placeholder={`Search ${field.label}`}
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          style={{ width: "70%", padding: 6, marginRight: 6 }}
        />
        <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}>
          Prev
        </button>
        <button type="button" onClick={() => setPage((p) => p + 1)} disabled={!hasNext} style={{ marginLeft: 6 }}>
          Next
        </button>
        {loading && <span style={{ marginLeft: 8 }}>Loading...</span>}
      </div>

      <select
        id={field.name}
        value={value ?? ""}
        onChange={(e) => onChange(field.name, e.target.value)}
        style={{ width: "100%", padding: 8, borderRadius: 4 }}
      >
        <option value="">{`Select ${field.label}`}</option>
        {opts.map((o) => (
          <option key={o.id} value={o.id}>
            {o.name ?? o.code ?? o.hs_code ?? o.norm_class ?? o.label ?? String(o.id)}
          </option>
        ))}
      </select>
    </div>
  );
};

export default function DynamicForm() {
  const [schema, setSchema] = useState(null);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getLicenseSchema()
      .then((s) => {
        setSchema(s);
        // init defaults
        const initial = {};
        s.fields.forEach((f) => (initial[f.name] = f.default ?? ""));
        setForm(initial);
      })
      .catch((err) => {
        toast.error("Failed to load schema");
      });
  }, []);

  const handleChange = (name, value) => {
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Note: adapt payload shape if nested children are required
      const payload = { ...form };
      const data = await submitLicense(payload);
      toast.success("License created");
      // optionally navigate or clear form
      setForm({});
    } catch (err) {
      // error toasted by interceptor; add contextual message
    } finally {
      setLoading(false);
    }
  };

  if (!schema) return <div>Loading form...</div>;

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: 900, margin: "0 auto", padding: 20 }}>
      <h2 style={{ color: "#ff7f00" }}>{schema.model} — Create</h2>
      {schema.fields.map((field) => (
        <div key={field.name} style={{ marginBottom: 12 }}>
          <label htmlFor={field.name} style={{ display: "block", marginBottom: 6 }}>
            {field.label} {field.required ? "*" : ""}
          </label>

          {field.type === "select" ? (
            <SelectWithSearch field={field} value={form[field.name]} onChange={handleChange} />
          ) : field.type === "multiselect" ? (
            // a simple multi-select
            <select
              multiple
              value={form[field.name] || []}
              onChange={(e) =>
                handleChange(
                  field.name,
                  Array.from(e.target.selectedOptions, (o) => o.value)
                )
              }
              style={{ width: "100%", padding: 8 }}
            >
              {/* load first page of options synchronously on mount would be nicer */}
            </select>
          ) : (
            <Input field={field} value={form[field.name]} onChange={handleChange} />
          )}
        </div>
      ))}

      <div style={{ marginTop: 18 }}>
        <button type="submit" disabled={loading} style={{ background: "#ff7f00", color: "#fff", padding: "10px 16px", border: "none", borderRadius: 4 }}>
          {loading ? "Saving..." : "Save"}
        </button>
      </div>
    </form>
  );
}
