// frontend/postcss.config.cjs
module.exports = {
  plugins: {
    // Use the new adapter package
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
