import React from 'react';
import GenericForm from '../../components/crud/GenericForm';
import { licenseLocalSchema } from '../../services/crudConfig';
import { useParams, useNavigate } from 'react-router-dom';

export function LicenseFormPage({ editMode = false }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const cfg = { ...licenseLocalSchema, onSuccess: () => navigate('/licenses') };
  return <GenericForm resource="licenses" config={cfg} editMode={editMode} id={id} />;
}
