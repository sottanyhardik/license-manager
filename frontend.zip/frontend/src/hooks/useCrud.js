import { useState, useCallback } from 'react';
import toast from 'react-hot-toast';

export default function useCrud({ list, get, create, update, remove }) {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const fetchList = useCallback(async (...args) => {
    setLoading(true);
    try { return await list?.(...args); } finally { setLoading(false); }
  }, [list]);

  const fetchOne = useCallback(async (id) => {
    setLoading(true);
    try { return await get?.(id); } finally { setLoading(false); }
  }, [get]);

  const createOne = useCallback(async (payload) => {
    setSaving(true);
    try {
      const res = await create?.(payload);
      toast.success('Created');
      return res;
    } finally { setSaving(false); }
  }, [create]);

  const updateOne = useCallback(async (id, payload) => {
    setSaving(true);
    try {
      const res = await update?.(id, payload);
      toast.success('Updated');
      return res;
    } finally { setSaving(false); }
  }, [update]);

  const deleteOne = useCallback(async (id) => {
    setSaving(true);
    try {
      const res = await remove?.(id);
      toast.success('Deleted');
      return res;
    } finally { setSaving(false); }
  }, [remove]);

  return { loading, saving, fetchList, fetchOne, createOne, updateOne, deleteOne };
}
