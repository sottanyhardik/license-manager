// src/api/licenseApi.js
import apiClient from "./apiClient";

export const getLicenseSchema = () => apiClient.get("/license/licenses/schema/").then((r) => r.data);

export const submitLicense = (payload) =>
  apiClient.post("/license/licenses/", payload).then((r) => r.data);

// options endpoints support search & pagination
export const fetchOptions = (endpoint, { search = "", page = 1, page_size = 25 } = {}) => {
  const params = {};
  if (search) params.search = search;
  if (page) params.page = page;
  if (page_size) params.page_size = page_size;
  return apiClient.get(endpoint, { params }).then((r) => r.data);
};
