import client from './apiClient';

// license endpoints (adjust if your Django uses /api/licenses/)
export const api = {
  // Auth
  login: (creds) => client.post('/auth/login/', creds).then(r => r.data),
  me: () => client.get('/auth/me/').then(r => r.data).catch(() => null),

  // Schema helper: try /schema/:resource (server-driven UI)
  fetchSchema: (resource) => client.get(`/schema/${resource}/`).then(r => r.data).catch(() => null),

  // License CRUD
  listLicenses: (params = '') => client.get(`/licenses/${params}`).then(r => r.data),
  getLicense: (id) => client.get(`/licenses/${id}/`).then(r => r.data),
  createLicense: (payload) => client.post('/licenses/', payload).then(r => r.data),
  updateLicense: (id, payload) => client.put(`/licenses/${id}/`, payload).then(r => r.data),
  deleteLicense: (id) => client.delete(`/licenses/${id}/`).then(r => r.data),

  // Generic helpers
  get: (url) => client.get(url).then(r => r.data),
  post: (url, data) => client.post(url, data).then(r => r.data),
  put: (url, data) => client.put(url, data).then(r => r.data),
  del: (url) => client.delete(url).then(r => r.data),
};

export default api;
