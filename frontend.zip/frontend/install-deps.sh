#!/usr/bin/env bash
set -euo pipefail

echo "📦 Checking and installing project dependencies (one by one)..."

# Helper function to check and install if missing
install_if_missing() {
  local pkg="$1"
  local dev="${2:-false}"
  if npm list "$pkg" >/dev/null 2>&1; then
    echo "✅ $pkg already installed"
  else
    if [ "$dev" = true ]; then
      echo "⬇️ Installing dev dependency: $pkg ..."
      npm install -D "$pkg"
    else
      echo "⬇️ Installing dependency: $pkg ..."
      npm install "$pkg"
    fi
  fi
}

# 🧠 Regular dependencies
install_if_missing react
install_if_missing react-dom
install_if_missing axios
install_if_missing react-hot-toast
install_if_missing jwt-decode
install_if_missing clsx

# ⚙️ Dev dependencies
install_if_missing vite true
install_if_missing @vitejs/plugin-react true
install_if_missing tailwindcss true
install_if_missing postcss true
install_if_missing autoprefixer true

echo "✅ All dependencies verified and installed!"

# Optional: initialize Tailwind if not yet configured
if [ ! -f tailwind.config.js ]; then
  echo "⚙️ Initializing Tailwind CSS..."
  npx tailwindcss init -p || npx tailwindcss@latest init -p
fi

echo "🎉 Setup complete!"
echo "Next steps:"
echo "  npm run dev  # to start your development server"
