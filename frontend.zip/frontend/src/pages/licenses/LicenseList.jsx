import React from 'react';
import GenericList from '../../components/crud/GenericList';
import { licenseLocalSchema } from '../../services/crudConfig';

export function LicenseListPage() {
  const cfg = { ...licenseLocalSchema, columns: [
    { key: 'id', label: '#' },
    { key: 'license_number', label: 'License#' },
    { key: 'exporter', label: 'Exporter', render: r => (r.exporter && r.exporter.name) || r.exporter || '-' },
    { key: 'license_expiry_date', label: 'Expiry' }
  ]};
  return <GenericList resource="licenses" config={cfg} />;
}
