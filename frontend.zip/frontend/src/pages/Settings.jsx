export default function Settings() {
  return <h1>Settings (Admin Only)</h1>;
}
